package dk.itu.mario.engine.sonar;


public interface SoundListener extends SoundSource
{
}