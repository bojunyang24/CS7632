The instructor solution is obfuscated and then compiled to bytecode. 

To use the instructor AStarNavigator2 solution:

1. Delete the empty astarnavigator2.py from the homework directory

2. Delete the __pycache__ directory (if it exists) from the homework directory

3. Copy astarnavigator2.pyc to the homework directory